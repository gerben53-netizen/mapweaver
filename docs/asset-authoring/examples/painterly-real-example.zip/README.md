# painterly-real-example

One actual shipped Painterly World entry with unchanged artwork and supported metadata. Original usage notice is retained; arbitrary extras are not preserved by library re-export.

REQUIRED: keep the manifest at the ZIP root. OPTIONAL: omit sha256 after replacing images, or update it. RECOMMENDED: replace example metadata with your own accurate metadata.
